import { Component, signal } from '@angular/core';
import { PostService, Post } from '../../services/post.services';
import { NavbarTop } from '../../components/navbar-top/navbar-top';
import { NavbarLeft } from '../../components/navbar-left/navbar-left';
import { NavbarRight } from '../../components/navbar-right/navbar-right';
import { PostComponent } from '../../components/post/post';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, NavbarTop, NavbarLeft, NavbarRight, PostComponent],
  templateUrl: './home.html',
  styleUrls: ['./home.css']
})
export class Home {
  currentView = signal('home');
  newPostModal = signal(false);
  posts = signal<Post[]>([]);
  carregando = signal(false);
  erro = signal('');

  constructor(private postService: PostService, private router: Router) { }

  ngOnInit() {
    const isLogged = localStorage.getItem('isLogged') === 'true';
    if (!isLogged) {
      this.router.navigate(['/login']);
      return;
    }
    this.carregarPosts();
  }

  carregarPosts() {
    this.carregando.set(true);
    this.postService.getPosts().subscribe({
      next: (dados) => {
        this.posts.set(dados);
        this.carregando.set(false);
      },
      error: () => {
        this.erro.set('Erro ao carregar postagens.');
        this.carregando.set(false);
      }
    });
  }

  openNewPost() {
    this.newPostModal.set(true);
  }

  closeNewPost() {
    this.newPostModal.set(false);
  }


  enviarPost(titulo: string, descricao: string) {
    const novaOportunidade: Oportunidade = {
      titulo,
      descricao,
      professorId: 'idProfessorFake',
      idCategoria: 'idCategoriaFake',
      vagasTotais: 1
    };

    this.oportunidadeService.criar(novaOportunidade).subscribe({
      next: (resp) => {
        this.oportunidades.update(lista => [resp, ...lista]);
        this.newPostModal.set(false);
      },
      error: (err) => {
        console.error('Erro ao criar oportunidade:', err);
      }
    });
  }
}