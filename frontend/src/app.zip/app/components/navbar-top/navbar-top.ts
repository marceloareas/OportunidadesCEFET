import { Component } from '@angular/core';

@Component({
  selector: 'app-navbar-top',
  imports: [],
  templateUrl: './navbar-top.html',
  styleUrl: './navbar-top.css'
})
export class NavbarTop {

}
