import { Component } from '@angular/core';

@Component({
  selector: 'app-post',
  standalone: true,
  templateUrl: './post.html',
  styleUrl: './post.css'
})
export class PostComponent {
}