import { Component } from '@angular/core';
import { Post } from '../post/post';

@Component({
  selector: 'app-group',
  imports: [Post],
  templateUrl: './group.html',
  styleUrl: './group.css'
})
export class Group {

}
